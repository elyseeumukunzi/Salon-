import React from 'react';
import { Avatar, Button, Icon, Layout, ListItem, MenuItem, OverflowMenu, Text } from '@ui-kitten/components';
import { RefreshControl, StyleSheet, ToastAndroid, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Reactotron from 'reactotron-react-native'
import axios from 'axios';
import { ScrollView } from 'react-native-gesture-handler';

var baseUrl = "https://standtogetherforchange.org";

const InstallButton = (props) => (
    <Icon
        style={styles.icon}
        fill='#8F9BB3'
        name='arrow-down-outline'
    />
);

const ItemImage = (props, employee) => (
    <Avatar
        {...props}
        style={[props.style, { tintColor: null }]}
        source={employee.ImagePath ? { uri: baseUrl + '/' + employee.ImagePath } : require('./assets/image-background.jpg')}
    />
);

export const ViewEmployeesScreen = ({ navigation, route }) => {
    const [employees, setEmployees] = React.useState([
        {
            names: 'Elysee'
        },
        {
            names: 'Elvis'
        }
    ]);
    const [refreshing, setRefreshing] = React.useState(false);

    /* const fetchData = async () => {
        Reactotron.log({ params });

        try {
            // get the data from the api
            const response = await axios({
                method: 'get',
                url: `${baseUrl}/api.php`,
                params: params,
            });

            Reactotron.log({
                response, params
            });
            // convert the data to json
            if (response.status === 200) {
                // set state with the result
                setEmployees(response.data);
            } else {
                // Reactotron.log(response);
                throw new Error("An error has occurred");
            }
        } catch (error) {
            Reactotron.log({ error });
            console.error(error);
        }
    } */

    /* React.useEffect(() => {
        // call the function
        fetchData();
    }, []); */

    const _onRefresh = () => {
        setRefreshing(true);
        fetchData().then(() => {
            setRefreshing(false);
        });
    }

    return (
        <ScrollView
            refreshControl={
                <RefreshControl
                    refreshing={refreshing}
                    onRefresh={_onRefresh}
                />
            }
        >
            {Array.isArray(employees) && employees.map((employee, index) => (
                <ListItem
                    key={index}
                    title={`${employee.names}`}
                    accessoryLeft={(props) => ItemImage(props, employee)}
                    onPress={() => navigation.navigate('EmployeeDetails', { employee })}
                />
            ))}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    icon: {
        width: 32,
        height: 32,
    },
    container: {
        flex: 1,
        flexDirection: 'row',
    },
    layout: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});