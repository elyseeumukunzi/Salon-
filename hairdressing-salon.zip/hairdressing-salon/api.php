<?php
include "conn.php";

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $response = array();
    $target = $_GET['target'];
    if ($target == "sign-in") {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $stmt = $mysqli->prepare("SELECT * FROM users WHERE Email = ? AND Password = ?");
        $stmt->bind_param("cc",$email,$password);
        // Execute query
        $stmt->execute();
        // Store result
        $result = $stmt->get_result();
        // Check if user exists
        if ($result->num_rows > 0) {
            $response['value'] = 1;
            $response['message'] = "Login success";
            $response['email'] = $email;
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Login failed";
            echo json_encode($response);
        }
    } else if ($target == "sign-up") {
        // Names
        $fullnames = $_POST['names'];        
        $phoneNumber = $_POST["phoneNumber"];
        $email = $_POST['email'];
        $password = $_POST['password'];        
        $location = $_POST['location'];        
        $userName = $_POST['userName'];
        $role="manager";

        // Use prepared statements
        $stmt = $mysqli->prepare("INSERT INTO users (FullName, Email, Contact, Location, UserName, Password,Role) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ccccccc",$fullnames,$email,$phoneNumber,$location,$userName,$password,$role);

        // Execute query
        if ($stmt->execute()) {
            $response['value'] = 1;
            $response['message'] = "Sign up success";
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Sign up failed";
            echo json_encode($response);
        }
        
    }
    if ($target == "add_product") {
        // Names
        $name = $_GET['name'];        
        $price = $_GET["price"];
        $quantity=$_GET['quantity'];
        $profile='profile.jpg';

        // Use prepared statements
        $stmt = $conn->prepare("INSERT INTO products (Name, Price, Profile,Quantity) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sdsd",$name,$price,$profile,$quantity);
        // Execute query
        if ($stmt->execute()) {
            $response['value'] = 1;
            $response['message'] = "Product added";
            $response['id']=$conn->insert_id;
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "add product failed";
            echo json_encode($response);
       }
        
    }
    
    else if ($target == "add_service") {
        // Names
        $name = $_GET['name'];        
        $price = $_GET["price"];
        $profile="profije.jpg";

        // Use prepared statements
        $stmt = $conn->prepare("INSERT INTO services (Name, Price, Profile) VALUES (?, ?, ?)");
        $stmt->bind_param("sds",$name,$price,$profile);

        // Execute query

        if ($stmt->execute()) {
            $response['value'] = 1;
            $response['message'] = "services added";
            $response['id'] =$conn->insert_id;
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "add service failed";
            echo json_encode($response);
        }
        
    }
    

    else if ($target == "add_employee") {
        // Names
        $fullname = $_GET['name'];        
        $location = $_GET["location"];
        $phoneNumber=$_GET['phone'];
        $idNumber=$_GET['id'];

        // Use prepared statements
        $stmt = $mysqli->prepare("INSERT INTO employees (FullName, Location, Contacts,IdNumber) VALUES (?, ?, ?, ?)");
        // Execute query
        $stmt->bind_param("cccc",$fullname,$location,$phoneNumber,$idNumber);

        if ($stmt->execute()) {
            $response['value'] = 1;
            $response['message'] = "new employee added";
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to add employee";
            echo json_encode($response);
        }
        
    } else if ($target == "add_contract") {
        // Names
        $Tittle = $_GET['title'];        
        $Length = $_GET["lenght"];
        $StartingDate=$_GET['startdate'];
        $EndingDates=$_GET['enddate'];
        $EmployeeId=$_GET['employeeid'];
        $JobPercentage=$_GET['percentage'];

        // Use prepared statements
        $stmt = $mysqli->prepare("INSERT INTO contracts (Tittle, Length, StartingDate,EndingDates,EmployeeId,JobPercentage) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("cccc",$Tittle,$Length,$StartingDate,$EndingDates,$EmployeeId,$JobPercentage);

        // Execute query

        if ($stmt->execute()) {
            $response['value'] = 1;
            $response['message'] = "new employee added";
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to add employee";
            echo json_encode($response);
        }
        
    }

    else if ($target == "get_products") {
        // Use prepared statements
        $stmt = $conn->prepare("SELECT * FROM products ORDER by Id DESC");
        //execute stmt
       if($stmt->execute ()) {
            $result=$stmt->get_result();
            $response=$result->fetch_all(MYSQLI_ASSOC);
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }
    
    else if ($target == "get_services") {
        // Use prepared statements
         $id=$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM services ORDER by Id DESC");
        //execute stmt
       if($stmt->execute ()) {
            $result=$stmt->get_result();
            $response=$result->fetch_all(MYSQLI_ASSOC);
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }
    
    else if ($target == "get_product") {
        // Use prepared statements
        $id=$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM products WHERE Id= $id");
        //execute stmt
       if($stmt->execute ()) {
            $result=$stmt->get_result();
            $response=$result->fetch_all(MYSQLI_ASSOC);
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }
     else if ($target == "get_service") {
        // Use prepared statements
        $id=$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM services WHERE Id= $id");
        //execute stmt
       if($stmt->execute ()) {
            $response=$stmt->get_result();
            echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }
    else if ($target == "get_employees") {
        // Use prepared statements        
        $stmt = $mysqli->prepare("SELECT * FROM employees ORDER by Id DESC");
        //execute stmt

       if ($stmt->execute()) {
        $result=$stmt->get_result();
        $response=$result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }
    else if ($target == "get_employee") {
        // Use prepared statements
        $id=$_GET['id'];
        $stmt = $mysqli->prepare("SELECT * FROM employees WHERE Id=$id");
        //execute stmt

       if ($stmt->execute()) {
        $result=$stmt->get_result();
        $response=$result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }

    else if ($target == "get_contract") {
        // Use prepared statements        
        $stmt = $mysqli->prepare("SELECT * FROM contracts ORDER by Id DESC");
        //execute stmt

       if ($stmt->execute()) {
        $result=$stmt->get_result();
        $response=$result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }
    else if ($target == "get_contracts") {
        // Use prepared statements
        $id=$_GET['id'];
        $stmt = $mysqli->prepare("SELECT * FROM contracts WHERE Id=$id");
        //execute stmt

       if ($stmt->execute()) {
        $result=$stmt->get_result();
        $response=$result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($response);
        } else {
            $response['value'] = 0;
            $response['message'] = "Failed to select";
            echo json_encode($response);
        }
        
    }

}
?>