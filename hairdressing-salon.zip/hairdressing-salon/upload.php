<?php
include "conn.php";

if (!empty($_FILES['photo']['name'])) {
    $target_dir = "images/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777);
    }
    $target_file = $target_dir . basename($_FILES["photo"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    // Check if file already exists
    if (file_exists($target_file)) {
        echo json_encode(
            array(
                "status" => 0,
                "data" => array(), "msg" => "Sorry, file already exists."
            )
        );
        die();
    }
    // Check file size
    if ($_FILES["photo"]["size"] > 50000000) {
        echo json_encode(
            array(
                "status" => 0,
                "data" => array(),
                "msg" => "Sorry, your file is too large."
            )
        );
        die();
    }
    if (
        move_uploaded_file(
            $_FILES["photo"]["tmp_name"],
            $target_file
        )
    ) {
        $table = $_POST['category'];
        // Update ImagePath in product table
        $stmt = $mysqli->prepare("UPDATE $table SET Profile = ? WHERE Id = ?");
        $stmt->bind_param("si", $target_file, $_POST['id']);
        $stmt->execute();
        $stmt->close();
        echo json_encode(
            array(
                "status" => 1,
                "data" => array(),
                "msg" => "The file " .
                    basename($_FILES["photo"]["name"]) .
                    " has been uploaded."
            )
        );
    } else {
        echo json_encode(
            array(
                "status" => 0,
                "data" => array(),
                "msg" => "Sorry, there was an error uploading your file."
            )
        );
    }
}
