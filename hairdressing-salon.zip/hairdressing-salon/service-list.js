import React from 'react';
import { Dimensions, ImageBackground, ListRenderItemInfo, View } from 'react-native';
import { Button, Card, Icon, List, StyleService, Text, useStyleSheet } from '@ui-kitten/components';
import { CartIcon } from './extra/icons';
import { Product as Service } from './extra/data';
import axios from 'axios';
import Reactotron from 'reactotron-react-native'
import AsyncStorage from '@react-native-async-storage/async-storage';

const services = [
    Service.pinkChair(),
    Service.blackLamp(),
    Service.whiteChair(),
    Service.woodChair(),
    Service.pinkChair(),
    Service.blackLamp(),
    Service.whiteChair(),
    Service.woodChair(),
];

var baseUrl = "https://standtogetherforchange.org";

export const ServiceListScreen = ({ navigation, route }) => {
    let [services, setServices] = React.useState(
        [
            {
                ServiceName: 'Modern Women Hairstyle',
                Price: 23000,
                Description: 'sssss',
                ImagePath: require(`./assets/hair-style1.jpg`)
            },
            {
                ServiceName: 'Eyebrows Clipping',
                Price: 8000,
                Description: 'sssss',
                ImagePath: require(`./assets/eyebrows-clipper.jpg`)
            },
            {
                ServiceName: 'Men Dreadlocks',
                Price: 31000,
                Description: 'sssss',
                ImagePath: require(`./assets/men-dreadlocks-1.jpg`)
            },
            {
                ServiceName: 'Manicure',
                Price: 3000,
                Description: 'sssss',
                ImagePath: require(`./assets/French-Manicure-Tips-with-Pink-Flowers-nail-art-designs.jpg`)
            },
            {
                ServiceName: 'Pedicure',
                Price: 4500,
                Description: 'sssss',
                ImagePath: require(`./assets/summerpedi2.jpeg`)
            },
            {
                ServiceName: 'Women Dreadlocks',
                Price: 31000,
                Description: 'sssss',
                ImagePath: require(`./assets/women-dreadlock1.jpg`)
            }
        ]
    );
    const [userCategory, setUserCategory] = React.useState("");
    const styles = useStyleSheet(themedStyles);

    /* React.useEffect(() => {
        const fetchData = async () => {
            let session = await AsyncStorage.getItem('@session');
            session = JSON.parse(session);
            const id = session.id;

            setUserCategory(session.userCategory);

            const params = {
                target: 'services',
                userCategory: session.userCategory,
                id
            };
            try {
                // get the data from the api
                const response = await axios({
                    method: 'get',
                    url: `${baseUrl}/api.php`,
                    params: params,
                });
                // set the data to the services state
                setServices(response.data);
            } catch (error) {
                console.error(error);
            }
        };
        fetchData();
    }, []); */

    const displayServices = services.filter(service => service.category === route.name);

    const onItemPress = (item) => {
        navigation && navigation.navigate('ViewService', { item, userCategory });
    };

    const onItemCartPress = (index) => {
        navigation && navigation.navigate('ShoppingCart');
    };

    const renderItemFooter = (info) => {
        Reactotron.log({ info });
        return (
            <View style={styles.itemFooter}>
                <Text category='s1'>
                    {info.item.Price} RWF
                </Text>
                {/* <Button
                style={styles.iconButton}
                size='small'
                accessoryLeft={CartIcon}
                onPress={() => onItemCartPress(info.index)}
            /> */}
            </View>
        );
    }

    const renderItemHeader = (info) => (
        <ImageBackground
            style={styles.itemHeader}
            source={info.item.ImagePath ? info.item.ImagePath : require('./assets/image-product-3.jpg')}
        />
    );

    const renderServiceItem = (info) => (
        <Card
            style={styles.serviceItem}
            header={() => renderItemHeader(info)}
            footer={() => renderItemFooter(info)}
            onPress={() => onItemPress(info.item)}>
            <Text category='s1'>
                {info.item.ServiceName}
            </Text>
        </Card>
    );

    const PlusIcon = (props) => (
        <Icon {...props} name='plus' />
    )

    const onNewButton = () => {
        navigation && navigation.navigate('CreateService', {
            context: 'create',
        });
    };

    return (
        <>
            {userCategory === "supplier" && <View>
                <Button style={styles.button} status='primary' accessoryLeft={PlusIcon} onPress={onNewButton}>
                    NEW
                </Button>
            </View>
            }
            <List
                contentContainerStyle={styles.serviceList}
                data={services}
                numColumns={2}
                renderItem={renderServiceItem}
            />
        </>
    );
};

const themedStyles = StyleService.create({
    container: {
        flex: 1,
        backgroundColor: 'background-basic-color-2',
    },
    serviceList: {
        paddingHorizontal: 8,
        paddingVertical: 16,
    },
    serviceItem: {
        flex: 1,
        margin: 8,
        maxWidth: Dimensions.get('window').width / 2 - 24,
        backgroundColor: 'background-basic-color-1',
    },
    itemHeader: {
        height: 140,
    },
    itemFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 20,
        paddingHorizontal: 20,
    },
    iconButton: {
        paddingHorizontal: 0,
    },
});